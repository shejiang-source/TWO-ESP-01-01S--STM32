#ifndef __USART_H
#define __USART_H
#include "stm32f10x.h"


void led_init(void);
void key_init(void);
void USART1_Config(void);
void USART_SendString(USART_TypeDef* USARTx, char* str);
uint8_t Key_GetNum(void);

#endif
