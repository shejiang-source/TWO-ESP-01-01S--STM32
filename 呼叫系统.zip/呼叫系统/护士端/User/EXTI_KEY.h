#ifndef __EXTI_KEY_H
#define __EXTI_KEY_H

#include "stm32f10x.h"

void EXTI_PE_Configuration(void);

#endif
