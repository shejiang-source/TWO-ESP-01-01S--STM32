#ifndef __USART_H
#define __USART_H
#include "stm32f10x.h"


void led(void);
void key(void);
void USART1_Config(void);
void USART_SendString(USART_TypeDef* USARTx, char* str);

#endif
