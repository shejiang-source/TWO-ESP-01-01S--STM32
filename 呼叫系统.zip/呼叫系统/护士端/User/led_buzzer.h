#ifndef __led_buzzer_H
#define __led_buzzer_H
void led_buzzer_init(void);
void green_ON(void);
void green_OFF(void);
void red_ON(void);
void red_OFF(void);
void buzzer_ON(void);
void buzzer_OFF(void);


#endif
